from flask import Flask, jsonify
import requests
from bs4 import BeautifulSoup
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow frontend access

@app.route('/bd-news')
def get_bd_news():
    url = 'https://bdnews24.com'
    res = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
    soup = BeautifulSoup(res.text, 'html.parser')

    news_items = []

    for item in soup.select('.leading-news a')[:10]:
        title = item.get_text(strip=True)
        link = item.get('href')
        if not link.startswith('http'):
            link = url + link
        news_items.append({
            'title': title,
            'url': link,
            'summary': ''
        })

    return jsonify({'articles': news_items})

if __name__ == '__main__':
    app.run(debug=True)
